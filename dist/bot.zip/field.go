package main

type Field struct {
	Rows          [][]byte
	Width, Height int
}
